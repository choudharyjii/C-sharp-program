﻿// See https://aka.ms/new-console-template for more information
// Console.WriteLine("Hello, World!");

using System;
class Tu
{
   static void Main(string []args) 
    {
        DateTime today = DateTime.Now;
        DateTime future = today.AddDays(40);

        string days = future.DayOfWeek.ToString();

        // Console.WriteLine($"Today {today:dddd}");

        Console.WriteLine($"40 days from future day {days} ");
    }
}

