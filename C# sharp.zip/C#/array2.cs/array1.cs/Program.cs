﻿using System;

class array
{
    public static void Main()
    {
        Console.WriteLine("Enter the size of square matrix:-");
        int size = Convert.ToInt32(Console.ReadLine());

        int[,]matrix = new int[size, size];

        Console.WriteLine("Input element in the matrix");

        for(int i=0; i<size; i++)
        {
            for(int j=0; j<size; j++)
            {
                Console.Write($"element-[{i}, {j}]");
                matrix[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        int sum = 0;
        for(int i=0; i<size; i++){
            sum += matrix[i, size-1-i];
        }

        Console.WriteLine($"Sum of the right diagonal elements:{sum}");
    }
}