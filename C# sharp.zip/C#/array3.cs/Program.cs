﻿using System;

class Program
{
    static void Main()
    {
        
        string[] words = { "This", "is", "a", "string", };

        
        Array.Sort(words);

        
        Console.WriteLine("Sorted array in ascending order:");
        foreach (string word in words)
        {
            Console.WriteLine(word);
        }
    }
}
