﻿using System;

namespace EmployeeApp
{
    struct Department
    {
        public string DepartmentName;
    }

    struct Employee
    {
        public string Name;
        public Department EmpDepartment;
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            Employee employee1;

            employee1.Name = "Pawan Choudhary";
            employee1.EmpDepartment.DepartmentName = "Computer Science";

            Console.WriteLine("Employee Name: " + employee1.Name);
            Console.WriteLine("Department: " + employee1.EmpDepartment.DepartmentName);
        }
    }
}