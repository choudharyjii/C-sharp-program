﻿using System;

namespace AnimalSoundDemo
{

    public abstract class Animal
    {

        public string Name { get; set; }

        public abstract void MakeSound();
    }

    public class Dog : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine($"{Name} says: Woof!");
        }
    }

    public class Cat : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine($"{Name} says: Meow!");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Dog dog = new Dog();
            dog.Name = "Buddy";

            Cat cat = new Cat();
            cat.Name = "Whiskers";

            Animal[] animals = { dog, cat };
            foreach (Animal animal in animals)
            {
                animal.MakeSound();
            }

            Console.ReadLine();
        }
    }
}