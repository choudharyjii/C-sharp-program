﻿using System;


class BaseClass
{
    public virtual void Show()
    {
        Console.WriteLine("Base class");
    }
}


class Derived : BaseClass
{
    
    public override void Show()
    {
        Console.WriteLine("Derived class");
    }
}

class Program
{
    static void Main(string[] args)
    {
        
        BaseClass baseInstance = new BaseClass();
        baseInstance.Show();  

        
        BaseClass derivedInstance = new Derived();
        derivedInstance.Show();  

        
        Console.WriteLine("\nPolymorphism demonstration:");
        
        BaseClass[] objects = { baseInstance, derivedInstance };

        foreach (BaseClass obj in objects)
        {
            obj.Show();  
        }
    }
}