﻿using System;

class Geometry
{
    
    public double Area(double radius)
    {
        return Math.PI * radius * radius;
    }

    
    public double Area(double length, double width)
    {
        return length * width;
    }

    public double Area(double baseLength, double height, bool isTriangle)
    {
        return 0.5 * baseLength * height;
    }

    static void Main(string[] args)
    {
        Geometry calculator = new Geometry();

      
        double circleArea = calculator.Area(5.0);
        Console.WriteLine("Area of circle with radius 5.0: " + circleArea);

     
        double rectangleArea = calculator.Area(4.0, 6.0);
        Console.WriteLine("Area of rectangle with length 4.0 and width 6.0: " + rectangleArea);

       
        double triangleArea = calculator.Area(3.0, 7.0, true);
        Console.WriteLine("Area of triangle with base 3.0 and height 7.0: " + triangleArea);
    }
}