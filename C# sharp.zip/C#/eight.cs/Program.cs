﻿using System;
class cube
{
    public static void Main( string[] args)
    {
    Console.WriteLine("Enter any numbers");
    double num = Convert.ToDouble(Console.ReadLine());

   double cube = Math.Pow(num, 3);

   Console.WriteLine("The cube of " + num + " is " + cube);
    }
}