﻿using System;

class ElectricityBill
{
    static void Main()
    {
        Console.Write("Enter Customer Name: ");
        string customerName = Console.ReadLine();

        Console.Write("Enter Customer ID: ");
        string customerID = Console.ReadLine();

        Console.Write("Enter Units Consumed: ");
        int unitsConsumed = int.Parse(Console.ReadLine());

        double totalAmount = 0;

    
        if (unitsConsumed <= 199)
        {
            totalAmount = unitsConsumed * 1.20;
        }
        else
        {
            if (unitsConsumed < 400)
            {
                totalAmount = unitsConsumed * 1.50;
            }
            else
            {
                if (unitsConsumed < 600)
                {
                    totalAmount = unitsConsumed * 1.80;
                }
                else
                {
                    totalAmount = unitsConsumed * 2.00;
                }
            }
        }

        if (totalAmount > 400)
        {
            totalAmount += 100; 
        }

        Console.WriteLine("\n--- Electricity Bill ---");
        Console.WriteLine("Customer Name: " + customerName);
        Console.WriteLine("Customer ID: " + customerID);
        Console.WriteLine("Units Consumed: " + unitsConsumed);
        Console.WriteLine("Total Amount Due: Rs. " + totalAmount);
    }
}