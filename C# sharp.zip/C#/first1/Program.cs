﻿class Program
{

    static void Main(string[] args)
    {
        Console.WriteLine("Please enter our name: ");
        string name = Console.ReadLine();
        Console.WriteLine("Please enter your age: ");
        int age = Convert.ToInt32(Console.ReadLine());
        int CurrentYear = DateTime.Now.Year;
        int birthYear = CurrentYear - age;

        Console.WriteLine( $"Hello, {name}! you were born in {birthYear}.");
    }
}
