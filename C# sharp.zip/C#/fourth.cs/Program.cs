﻿using System;

class Program
{
    static void Main()
    {
        
        Console.WriteLine("Enter marks obtained in Mathematics:");
        int mathMarks = int.Parse(Console.ReadLine());

        Console.WriteLine("Enter marks obtained in Physics:");
        int phyMarks = int.Parse(Console.ReadLine());

        Console.WriteLine("Enter marks obtained in Chemistry:");
        int chemMarks = int.Parse(Console.ReadLine());

    
        bool isMathEligible = mathMarks >= 65;
        bool isPhyEligible = phyMarks >= 55;
        bool isChemEligible = chemMarks >= 50;

        int totalMarks = mathMarks + phyMarks + chemMarks;
        int mathPhyTotal = mathMarks + phyMarks;
    
        if (totalMarks >= 180 && mathPhyTotal >=140)
        {
            Console.WriteLine("The candidate is eligible for admission.");
        }
        else if(chemMarks >= 50)
        {
            Console.WriteLine("The candidate is  eligible for admission.");
        }
        else if(mathMarks >=65)
        {
            Console.WriteLine("The candidate is   eligible for admission.");
        }
        else if(phyMarks >= 55)
        {
            Console.WriteLine("The candidate is  eligible for admission.");
        }
        else
        {
            Console.WriteLine("The candidate is not  eligible for admission.");
        }
    }
}