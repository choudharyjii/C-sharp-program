﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the number of terms in the Fibonacci sequence: ");
        int terms = int.Parse(Console.ReadLine());

        Console.WriteLine("Fibonacci Sequence:");
        DisplayFibonacci(terms);
    }

    static void DisplayFibonacci(int terms)
    {
        int first = 0, second = 1, next;

        for (int i = 0; i < terms; i++)
        {
            if (i <= 1)
            {
                next = i;
            }
            else
            {
                next = first + second;
                first = second;
                second = next;
            }
            Console.Write(next + " ");
        }
    }
}
