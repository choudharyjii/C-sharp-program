﻿using System;

class GPseries
{
    static void Main()
    {
        Console.WriteLine("Enter the first number (a):-");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Enter the common ratio (r):-");
        double r = Convert.ToDouble(Console.ReadLine());
        
        Console.WriteLine("Enter the  number of terms (num):-");
        int num = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("The GP series is:-");

        for(int i = 0; i < num; i++)
        {
             double term = a * Math.Pow(r, i);
            Console.WriteLine(term + " ");
        }
    }
}