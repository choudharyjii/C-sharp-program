﻿using System;

class AlphabetPattern
{
    static void Main()
    {
        int height = 6;
        
        for (int i = 0; i <= height; i++)
        {
            Console.Write("*");
        }
        Console.WriteLine();

//         for (int i = 1; i <= height; i++)
//         {
             for (int j = 1; j <= height; j++)
             {
                if (j == height / 2)
                    Console.Write("*");
                else
                     Console.Write(" ");
             }
//             Console.WriteLine();
//         }
    }
}