﻿using System;

namespace PasswordGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the desired length of the password: ");
            int length = int.Parse(Console.ReadLine());

            Console.WriteLine("Select the character type for the password:");
            Console.WriteLine("1. Only letters");
            Console.WriteLine("2. Only numbers");
            Console.WriteLine("3. Combination of letters and numbers");
            Console.Write("Enter your choice (1-3): ");
            int choice = int.Parse(Console.ReadLine());

            string password = GeneratePassword(length, choice);

            Console.WriteLine($"Generated Password: {password}");
        }

        static string GeneratePassword(int length, int choice)
        {
            const string letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
             const string numbers = "0123456789";
            string characters = "";

            switch (choice)
            {
                case 1:
                    characters = letters;
                    break;
                case 2:
                    characters = numbers;
                    break;
                case 3:
                    characters = letters + numbers;
                    break;
                default:
                    Console.WriteLine("Invalid choice. Defaulting to combination of letters and numbers.");
                    characters = letters + numbers;
                    break;
            }

            Random ran = new Random();
            char[] password = new char[length];
            for (int i = 0; i < length; i++)
            {
                password[i] = characters[ran.Next(characters.Length)];
            }

            return new string(password);
        }
    }
}