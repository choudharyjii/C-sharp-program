﻿using System;

class pawan
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the any year");
        int year = Convert.ToInt32(Console.ReadLine());

        if(year % 4 != 0)
        {
            Console.WriteLine("This is not a leap year");
        }
        else
        {
            Console.WriteLine("This is a leap year");
        }
    }
}